# Horizon Site Solutions — Vite + React + Tailwind

## Quick Deploy (Vercel)
1. Go to https://vercel.com → New Project → Deploy from your computer → drag this folder.
2. Build command: `npm run build` (auto-detected)
   Output directory: `dist` (auto-detected)
3. After deploy, Settings → Domains → Add:
   - horizonsitesolutions.com
   - www.horizonsitesolutions.com
4. Vercel will show DNS:
   - CNAME for `www` → `cname.vercel-dns.com`
   - A record for `@` → `76.76.21.21`
5. In Squarespace: Domains → your domain → DNS → add those two records exactly.
6. Wait for SSL to be issued automatically, then test https://www.horizonsitesolutions.com

## Formspree
In `src/App.jsx`, set:
```js
const FORM_ENDPOINT = "https://formspree.io/f/YOUR_ID";
```
Create a form at https://formspree.io, copy the `/f/xxxxx` URL, paste it in, deploy again.

## Edit Contact Info
Search `214-555-0134` and `hello@horizonsitesolutions.com` and replace.

## Local development
```bash
npm install
npm run dev
```
