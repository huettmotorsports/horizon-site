import React, { useMemo, useState } from 'react';

// ---- Formspree endpoint (replace REPLACE_ME with your form id) ----
const FORM_ENDPOINT = "https://formspree.io/f/REPLACE_ME";

const services = [
  { title: "Concrete Removal", blurb: "Break, load, and haul away old slabs, driveways, patios, and footings — clean, safe, and code‑compliant.",
    icon: (<svg viewBox="0 0 24 24" fill="currentColor" className="w-7 h-7"><path d="M3 3h18v2H3zM5 7h14v3H5zM3 12h18v2H3zM6 16h12v5H6z"/></svg>) },
  { title: "Construction Site Cleanup", blurb: "Pre‑ and post‑construction rough cleans so crews start faster and clients see a spotless handoff.",
    icon: (<svg viewBox="0 0 24 24" fill="currentColor" className="w-7 h-7"><path d="M4 4h16v4H4zM6 10h12v10H6z"/></svg>) },
  { title: "Debris Haul‑Off", blurb: "Tear‑out, brush, and jobsite debris — fast removal with responsible disposal and recycling where possible.",
    icon: (<svg viewBox="0 0 24 24" fill="currentColor" className="w-7 h-7"><path d="M7 4h10l1 3H6zM5 8h14l-1.5 12h-11z"/></svg>) },
  { title: "Land & Lot Prep", blurb: "Skid steer grading, small land clears, and pad prep to get your site ready to build.",
    icon: (<svg viewBox="0 0 24 24" fill="currentColor" className="w-7 h-7"><path d="M3 18h18v2H3zM4 10l8-6 8 6v8H4z"/></svg>) },
  { title: "Stump Removal", blurb: "Stump grinding and haul‑off so you can pour or landscape without delays.",
    icon: (<svg viewBox="0 0 24 24" fill="currentColor" className="w-7 h-7"><path d="M12 2l4 8H8l4-8zm-6 10h12v8H6z"/></svg>) },
  { title: "Concrete Cutting (Add‑On)", blurb: "Clean cuts and core drilling for utility runs and precise removals.",
    icon: (<svg viewBox="0 0 24 24" fill="currentColor" className="w-7 h-7"><path d="M4 12h16v2H4zM2 7h20v2H2zM6 16h12v2H6z"/></svg>) },
];

const faqs = [
  { q: "Which areas do you serve?", a: "We serve McKinney, Frisco, Allen, Plano, and the greater DFW metroplex. Call to confirm your location." },
  { q: "Are you insured?", a: "Yes. We carry general liability and commercial auto, and provide COIs upon request." },
  { q: "How fast can you start?", a: "Often within 24–48 hours for standard projects. Larger removals may require a brief site visit." },
  { q: "What about permits or disposal?", a: "We handle disposal with licensed facilities. If permitting is required, we’ll help you navigate it." },
];

const Stat = ({ value, label }) => (
  <div className="text-center p-4 rounded-2xl bg-white/60 shadow-sm">
    <div className="text-3xl font-semibold tracking-tight">{value}</div>
    <div className="text-sm text-gray-600">{label}</div>
  </div>
);

const Tag = ({ children }) => (
  <span className="px-2 py-1 rounded-full text-xs bg-emerald-100 text-emerald-700">{children}</span>
);

const Logo = () => (
  <svg viewBox="0 0 220 40" className="h-9 w-auto text-emerald-700" aria-label="Horizon Site Solutions">
    <defs>
      <linearGradient id="hz" x1="0" x2="1">
        <stop offset="0%" stopColor="#059669"/>
        <stop offset="100%" stopColor="#10b981"/>
      </linearGradient>
    </defs>
    <path d="M5 28c18-14 44-21 105-21s87 7 105 21" fill="none" stroke="url(#hz)" strokeWidth="4" strokeLinecap="round"/>
    <text x="8" y="33" fontFamily="Inter,ui-sans-serif,system-ui,Segoe UI,Roboto" fontSize="18" fontWeight="700" fill="#0f172a">Horizon</text>
    <text x="96" y="33" fontFamily="Inter,ui-sans-serif,system-ui,Segoe UI,Roboto" fontSize="18" fontWeight="500" fill="#334155">Site Solutions</text>
  </svg>
);

export default function App() {
  const [form, setForm] = useState({ name: "", phone: "", email: "", details: "" });
  const [status, setStatus] = useState({ ok: false, error: "" });

  const structuredData = useMemo(() => ({
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    name: "Horizon Site Solutions",
    url: "https://www.horizonsitesolutions.com",
    telephone: "+1-214-555-0134",
    areaServed: ["McKinney", "Frisco", "Allen", "Plano", "Dallas–Fort Worth"],
    sameAs: [
      "https://www.facebook.com/horizonsitesolutions",
      "https://www.google.com/search?q=horizon+site+solutions+mckinney"
    ],
    address: {
      "@type": "PostalAddress",
      streetAddress: "",
      addressLocality: "McKinney",
      addressRegion: "TX",
      postalCode: "",
      addressCountry: "US"
    },
    openingHours: "Mo-Fr 07:00-18:00, Sa 08:00-14:00",
    priceRange: "$$",
    serviceArea: { "@type": "Place", name: "DFW Metroplex" },
    makesOffer: services.map((s) => ({ "@type": "Service", name: s.title })),
  }), []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus({ ok: false, error: "" });
    try {
      const res = await fetch(FORM_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          phone: form.phone,
          email: form.email,
          details: form.details,
          _subject: "Quote request — Horizon Site Solutions",
        }),
      });
      if (res.ok) {
        setStatus({ ok: true, error: "" });
        setForm({ name: "", phone: "", email: "", details: "" });
      } else {
        const t = await res.text();
        setStatus({ ok: false, error: t || "Submission failed. Please call us." });
      }
    } catch {
      setStatus({ ok: false, error: "Network error. Please try again or call us." });
    }
  };

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 text-slate-900">
      {/* JSON-LD for SEO */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }} />

      {/* Top bar */}
      <header className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Logo />
            <div>
              <div className="font-semibold tracking-tight">Horizon Site Solutions</div>
              <div className="text-xs text-slate-500 -mt-0.5">Concrete Removal • Cleanup • Haul‑Off</div>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#services" className="hover:text-emerald-700">Services</a>
            <a href="#process" className="hover:text-emerald-700">Process</a>
            <a href="#about" className="hover:text-emerald-700">About</a>
            <a href="#contact" className="hover:text-emerald-700">Contact</a>
          </nav>
          <div className="flex items-center gap-2">
            <a href="tel:+12145550134" className="hidden sm:inline-flex px-3 py-2 rounded-xl border border-slate-300 hover:bg-white">(214) 555‑0134</a>
            <a href="#contact" className="inline-flex px-3 py-2 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700">Get a Quote</a>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="max-w-6xl mx-auto px-4 py-16 md:py-24 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <div className="mb-4 flex flex-wrap gap-2">
              <Tag>DFW Metroplex</Tag>
              <Tag>Insured</Tag>
              <Tag>Fast Scheduling</Tag>
            </div>
            <h1 className="text-4xl md:text-5xl font-semibold tracking-tight leading-tight">
              Concrete Removal & Construction Cleanup
              <span className="block text-emerald-700">Done Right — On Time.</span>
            </h1>
            <p className="mt-4 text-slate-600 max-w-prose">
              From demo day to final sweep, Horizon Site Solutions clears the way. We remove concrete, haul debris,
              prep pads, and leave job sites clean, safe, and ready.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href="#contact" className="px-4 py-3 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700">Get a Free Quote</a>
              <a href="tel:+12145550134" className="px-4 py-3 rounded-xl border border-slate-300 hover:bg-white">Call Now</a>
            </div>
            <div className="mt-8 grid grid-cols-3 gap-3">
              <Stat value="24–48 hrs" label="Typical Start" />
              <Stat value=">1,000" label="Cubic Yds Hauled" />
              <Stat value="100%" label="Satisfaction Focus" />
            </div>
          </div>

          <div className="relative">
            <div className="aspect-[4/3] rounded-3xl bg-white shadow-lg p-4 grid place-items-center">
              <div className="w-full h-full rounded-2xl bg-gradient-to-br from-emerald-50 to-emerald-100 border border-emerald-200 grid place-items-center">
                <div className="text-center px-6">
                  <div className="text-7xl">🛠️</div>
                  <p className="mt-2 font-medium">Skid steer + demo crew at the ready</p>
                  <p className="text-sm text-slate-600">Concrete, debris, and brush — gone.</p>
                </div>
              </div>
            </div>
            <div className="absolute -bottom-4 -right-4 hidden md:block">
              <div className="px-4 py-3 rounded-2xl bg-white shadow border text-sm">
                <span className="font-medium">Free on‑site estimates</span>
                <span className="text-slate-500"> · McKinney & DFW</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section id="services" className="py-16 md:py-24 border-t border-slate-200 bg-white/70">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-semibold tracking-tight">Services</h2>
          <p className="mt-2 text-slate-600 max-w-prose">
            Hire one crew that handles the mess end‑to‑end. If it’s heavy, dusty, or in your way — we’ll remove it and clean up.
          </p>
          <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {services.map((s) => (
              <div key={s.title} className="p-5 rounded-2xl bg-white shadow-sm border border-slate-200 hover:shadow-md transition">
                <div className="flex items-center gap-3">
                  <div className="text-emerald-700">{s.icon}</div>
                  <h3 className="font-semibold tracking-tight">{s.title}</h3>
                </div>
                <p className="mt-2 text-sm text-slate-600">{s.blurb}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section id="process" className="py-16 md:py-24 border-t border-slate-200">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-semibold tracking-tight">Our Process</h2>
          <div className="mt-8 grid md:grid-cols-4 gap-4">
            {[
              { n: 1, t: "Walk‑through", d: "Share photos or we visit the site for a quick scope." },
              { n: 2, t: "Fixed Quote", d: "Clear, itemized pricing with no surprises." },
              { n: 3, t: "Remove + Haul", d: "We demo, load, and dispose responsibly." },
              { n: 4, t: "Final Clean", d: "Sweep, magnetic nail pickup, and client sign‑off." },
            ].map((step) => (
              <div key={step.n} className="p-5 rounded-2xl bg-white shadow-sm border border-slate-200">
                <div className="w-8 h-8 rounded-full bg-emerald-600 text-white grid place-items-center font-semibold">{step.n}</div>
                <div className="mt-3 font-medium">{step.t}</div>
                <div className="text-sm text-slate-600">{step.d}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About */}
      <section id="about" className="py-16 md:py-24 border-t border-slate-200 bg-white/70">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-semibold tracking-tight">About Horizon</h2>
            <p className="mt-3 text-slate-700">
              We’re a local, Texas‑proud crew focused on reliability, safety, and clean finishes. With an established LLC and commercial coverage,
              we show up prepared and leave your site better than we found it.
            </p>
            <ul className="mt-4 space-y-2 text-slate-700">
              <li>• OSHA‑minded practices</li>
              <li>• Transparent, line‑item quotes</li>
              <li>• On‑time arrivals and pro communication</li>
            </ul>
          </div>
          <div className="p-5 rounded-3xl bg-white shadow border border-slate-200">
            <div className="text-sm text-slate-500 mb-2">Trusted by GC’s & homeowners</div>
            <div className="space-y-3">
              {[
                { n: "S. Ramirez", t: "Driveway demo + haul‑off", c: "Fast, fair, and spotless when finished." },
                { n: "North Collin Builders", t: "Rough clean + concrete removal", c: "Clear communication and on schedule." },
                { n: "A. Nguyen", t: "Patio tear‑out", c: "Zero hassles. Would hire again." },
              ].map((x, i) => (
                <div key={i} className="p-4 rounded-2xl border border-slate-200">
                  <div className="font-medium">{x.n}</div>
                  <div className="text-xs text-slate-500">{x.t}</div>
                  <div className="text-sm mt-1">“{x.c}”</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-16 md:py-24 border-t border-slate-200">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-semibold tracking-tight">FAQs</h2>
          <div className="mt-6 grid md:grid-cols-2 gap-5">
            {faqs.map((f, i) => (
              <div key={i} className="p-5 rounded-2xl bg-white shadow-sm border border-slate-200">
                <div className="font-medium">{f.q}</div>
                <div className="text-sm text-slate-600 mt-1">{f.a}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-16 md:py-24 border-t border-slate-200 bg-white">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-10">
          <div>
            <h2 className="text-3xl md:text-4xl font-semibold tracking-tight">Get a Free Quote</h2>
            <p className="mt-2 text-slate-600 max-w-prose">
              Send a few details and we’ll follow up quickly. For fastest service, call <a href="tel:+12145550134" className="underline">(214) 555‑0134</a>.
            </p>
            <form onSubmit={handleSubmit} className="mt-6 space-y-3">
              <div>
                <label className="text-sm font-medium">Name</label>
                <input
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="mt-1 w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  placeholder="Your name"
                />
              </div>
              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium">Phone</label>
                  <input
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    className="mt-1 w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    placeholder="(###) ###‑####"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Email</label>
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    className="mt-1 w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    placeholder="you@example.com"
                  />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium">Project Details</label>
                <textarea
                  required
                  rows={5}
                  value={form.details}
                  onChange={(e) => setForm({ ...form, details: e.target.value })}
                  className="mt-1 w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  placeholder="What do you need removed or cleaned? Include dimensions, access, photos, and timeline."
                />
              </div>

              {status.ok && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm">
                  Thanks! Your request was sent. We’ll get back to you shortly.
                </div>
              )}
              {status.error && !status.ok && (
                <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-800 text-sm">
                  {status.error}
                </div>
              )}

              <button type="submit" className="w-full sm:w-auto px-5 py-3 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700">
                Send Request
              </button>
            </form>
          </div>

          <div className="p-6 rounded-3xl bg-gradient-to-br from-slate-50 to-white border border-slate-200 shadow-sm">
            <div className="font-medium">Contact</div>
            <div className="mt-2 text-sm text-slate-700">
              <div>Phone: <a className="underline" href="tel:+12145550134">(214) 555‑0134</a></div>
              <div>Email: <a className="underline" href="mailto:hello@horizonsitesolutions.com">hello@horizonsitesolutions.com</a></div>
            </div>
            <div className="mt-6 font-medium">Service Area</div>
            <div className="mt-2 text-sm text-slate-700">McKinney • Frisco • Allen • Plano • DFW</div>
            <div className="mt-6 font-medium">Hours</div>
            <div className="mt-2 text-sm text-slate-700">Mon–Fri 7:00–6:00 • Sat 8:00–2:00</div>
            <div className="mt-6 font-medium">Docs & Insurance</div>
            <div className="mt-2 text-sm text-slate-700">COI available • Licensed disposal</div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10 border-t border-slate-200 bg-white/70">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-slate-600">
          <div>© {new Date().getFullYear()} Horizon Site Solutions. All rights reserved.</div>
          <div className="flex items-center gap-4">
            <a href="#services" className="hover:text-emerald-700">Services</a>
            <a href="#process" className="hover:text-emerald-700">Process</a>
            <a href="#about" className="hover:text-emerald-700">About</a>
            <a href="#contact" className="hover:text-emerald-700">Contact</a>
          </div>
        </div>
      </footer>
    </main>
  );
}
